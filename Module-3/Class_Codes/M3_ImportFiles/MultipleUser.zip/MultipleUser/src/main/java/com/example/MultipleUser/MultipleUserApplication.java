package com.example.MultipleUser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultipleUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultipleUserApplication.class, args);
	}
}
