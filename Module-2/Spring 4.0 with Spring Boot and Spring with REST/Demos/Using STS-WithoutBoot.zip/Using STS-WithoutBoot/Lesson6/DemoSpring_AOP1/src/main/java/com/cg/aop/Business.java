package com.cg.aop;


public interface Business {
    void doBusiness();
}
