package com.capgemini.lesson3.iteration;

public class ForEg {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 0; i < 10; i++) {
	        System.out.println(i + " ");
	    }

	}

}
